/* 
 * File:   USART.h
 * Author: jonam
 *
 * Created on 1 de agosto de 2021, 02:46 PM
 */

#ifndef USART_H
#define	USART_H

#include <xc.h> 

void configUSART(void);

#endif	/* USART_H */

