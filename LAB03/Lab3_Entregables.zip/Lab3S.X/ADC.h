/* 
 * File:   ADC.h
 * Author: jonam
 *
 * Created on 1 de agosto de 2021, 11:16 AM
 */

#ifndef ADC_H
#define	ADC_H

#include <xc.h> 
#include <stdint.h>

void configADC(char fr);

#endif	/* ADC_H */


